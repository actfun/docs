export const WORKFLOW_TYPES = [
  'changelog',
  'source-code-agent',
  'translations',
  'writing-style',
  'typo-check',
  'broken-link-detection',
  'seo-metadata-audit',
  'assistant-docs-updates',
  'contextual-feedback-docs-updates',
] as const;
export type WorkflowType = (typeof WORKFLOW_TYPES)[number];

export type WorkflowCronTrigger = { cron: string };
export type WorkflowPushTrigger = { push: { repo: string; branch?: string }[] };
export type WorkflowComposioTrigger = {
  composio: {
    toolkit: string;
    triggerSlug: string;
    composioTriggerId?: string;
    triggerConfig?: Record<string, unknown>;
  };
};

export type WorkflowTrigger = WorkflowCronTrigger | WorkflowPushTrigger | WorkflowComposioTrigger;

export type WorkflowContextItem = {
  repo: string;
  public?: boolean;
};

export type WorkflowNotify = {
  slack?: {
    channels?: string[];
    channel_ids?: string[];
    users?: string[];
    user_ids?: string[];
  };
};

export type WorkflowBody = {
  name: string;
  on: WorkflowTrigger;
  prompt?: string;
  type?: WorkflowType;
  context?: WorkflowContextItem[];
  automerge?: boolean;
  notify?: WorkflowNotify;
  config?: { translations?: { targetLanguages: string[] } };
  tools?: { composio?: { toolkit: string }[] };
};

export type Workflow = {
  _id: string;
  deploymentId: string;
  subdomain: string;
  name: string;
  prompt?: string;
  type?: WorkflowType;
  trigger: WorkflowTrigger;
  status: 'active' | 'disabled' | 'deleted';
  automerge?: boolean;
  context?: WorkflowContextItem[];
  notify?: WorkflowNotify;
  createdAt: string;
  updatedAt: string;
  lastRanAt?: string;
};
