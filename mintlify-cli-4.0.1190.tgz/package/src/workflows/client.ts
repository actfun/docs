import { authenticatedFetch } from '../authenticatedFetch.js';
import { API_URL } from '../constants.js';
import type { Workflow, WorkflowBody } from './types.js';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await authenticatedFetch(`${API_URL}/api/cli/workflows${path}`, {
    ...init,
    headers: { Accept: 'application/json', ...init?.headers },
  });

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`API error (${res.status}): ${body || res.statusText}`);
  }

  return res.json() as Promise<T>;
}

export function createWorkflow(subdomain: string, body: WorkflowBody): Promise<Workflow> {
  return request<Workflow>(`/${encodeURIComponent(subdomain)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

export function listWorkflows(subdomain: string): Promise<Workflow[]> {
  return request<Workflow[]>(`/${encodeURIComponent(subdomain)}`);
}

export function deleteWorkflow(
  subdomain: string,
  workflowSchemaId: string
): Promise<{ success: boolean }> {
  return request<{ success: boolean }>(
    `/${encodeURIComponent(subdomain)}/${encodeURIComponent(workflowSchemaId)}`,
    { method: 'DELETE' }
  );
}
